function schema()
% customplot package definition SCHEMA

% $$FileInfo
% $Filename: schema.m
% $Path: $toolboxroot/@customplots/
% $Product Name: <multiple>
% $Product Release: n/a
% $Revision: 1.0.1
% $Toolbox Name: Custom Plots Toolbox
% $$
%
% Copyright (c) 2011 John Barber.
%

schema.package('customplots');
